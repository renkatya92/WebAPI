const Pool = require('pg').Pool;
const Hash = require('crypto');
const pool = new Pool({
    user: 'api_user1',
    host: 'localhost',
    database: 'api_db',
    password: 'password',
    port: 5432,
});

const getBook = (request, response) => {
pool.query('SELECT * FROM book ORDER BY id ASC', (error, results) => {
        if (error) {
            throw error
        }
        response.status(200).json(results.rows)
    });
};


const getBookById = (request, response) => {
    const id = parseInt(request.params.id);
    pool.query('SELECT * FROM book WHERE id = $1', [id], (error, results) => {
        if (error) {
            throw error
        }
        response.status(200).json(results.rows)
    });
};

const createBook = (request, response) => {
    const { book_id, name, author, pgenre_id } = request.body;
    pool.query('INSERT INTO book (book_id, name, author, pgenre_id) VALUES ($1, $2, $3, $4) RETURNING *', [book_id, name, author, pgenre_id], (error, results) => {
        if (error) {
            throw error
        }
        response.status(201).send(`Book added with ID: ${results.rows[0].id}`)
    });
};

const updateBook = (request, response) => {
    const id = parseInt(request.params.id);
    const { book_id, name, author, pgenre_id } = request.body;
    pool.query(
        'UPDATE book SET book_id = $1, name = $2, author = $3, pgenre_id = $4 WHERE id = $5',[book_id, name, author, pgenre_id, id],(error, results) => {
            if (error) {
                throw error
            }
            response.status(200).send(`Book modified with ID: ${id}`)
        }
        );
};

const deleteBook = (request, response) => {
    const id = parseInt(request.params.id);
    pool.query('DELETE FROM book WHERE id = $1', [id], (error, results) => {
        if (error) {
            throw error
        }
        response.status(200).send(`Book deleted with ID: ${id}`)
    });
};

const createGenre = (request, response) => {
    const { genre_id, name_genre, description } = request.body;
    pool.query('INSERT INTO genre (genre_id, name_genre, description) VALUES ($1, $2, $3) RETURNING *', [genre_id, name_genre, description], (error, results) => {
        if (error) {
            throw error
        }
        response.status(201).send(`Genre added with ID: ${results.rows[0].id}`)
    });
};

const getGenre = (request, response) => {
    pool.query('SELECT * FROM genre ORDER BY id ASC', (error, results) => {
        if (error) {
        throw error
        }
        response.status(200).json(results.rows)
    });
};

const deleteGenre  = (request, response) => {
    const id = parseInt(request.params.id);
           throw error
      pool.query('DELETE FROM genre WHERE id = $1', [id], (error, results) => {
        if (error) {
       }
        response.status(200).send(`Genre deleted with ID: ${id}`)
    });
};



module.exports = {
    getBook,
    getGenre,
    getBookById,
    createBook,
    createGenre,
    updateBook,
    deleteBook,
    deleteGenre
};



