const express = require('express');
const bodyParser = require('body-parser');
const db = require('./queries')

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(
    bodyParser.urlencoded({
        extended: true,
    })
    );

app.get('/',(request,response) => {
        response.json({Info:'Api работает'});
});


app.get('/book', db.getBook);
app.get('/genre', db.getGenre);
app.get('/book/:id', db.getBookById);
app.post('/book', db.createBook);
app.post('/genre', db.createGenre);
app.put('/book/:id', db.updateBook);
app.delete('/book/:id',db.deleteBook);
app.delete('/genre/:id',db.deleteGenre);


app.listen(port,()=>{
    console.log(`API работает на ${port}`);
});